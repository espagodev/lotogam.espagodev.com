<?php

namespace Twf\Pps;

use Mike42\Escpos\Printer;
use Mike42\Escpos\EscposImage;
use Mike42\Escpos\CapabilityProfile;
use Mike42\Escpos\PrintConnectors\FilePrintConnector;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;

class Escpos
{
	
	public $printer;
	public $char_per_line = 42;
	

	public function load($printer) {
		
		if ($printer->connection_type == 'network') {
			set_time_limit(30);
			$connector = new NetworkPrintConnector($printer->ip_address, $printer->port);
		} elseif ($printer->connection_type == 'linux') {
			$connector = new FilePrintConnector($printer->path);
		} else {
			$connector = new WindowsPrintConnector($printer->path);
		}

		$this->char_per_line = $printer->char_per_line;

        $profile = CapabilityProfile::load($printer->capability_profile);
		$this->printer = new Printer($connector, $profile);
	}

	public function print_invoice($data, $print) {
 		$tipoGuion = '-';
	 	$tipoAsterisco = '*';

		if ($print === 'ticket'){
			//Print logo
			$this->printer->setJustification(Printer::JUSTIFY_CENTER);
			if (isset($data->logo) && !empty($data->logo)) {
				$logo = $this->download_image($data->logo);
				$logo = EscposImage::load($logo, false);
				$this->printer->bitImage($logo);
			}
			

			/* Nombre empresa */
			if (isset($data->display_name) && !empty($data->display_name)) {
				$this->printer->text($data->display_name);
				$this->printer->feed();
			}


			/* nombre banca */
			if (isset($data->invoice_heading) && !empty($data->invoice_heading)) {
				$this->printer->setEmphasis(true);
				$this->printer->text($data->invoice_heading);
				$this->printer->setEmphasis(false);
				$this->printer->feed(1);
			}

			/* Slogan */
			$this->printer->setJustification(Printer::JUSTIFY_CENTER);
			$this->printer->setEmphasis(true);
			$this->printer->setTextSize(1, 1);
			if (isset($data->slogan) && !empty($data->slogan)) {
				$this->printer->text(strip_tags($data->slogan));
				$this->printer->feed();
			}

			// $this->printer->setJustification(Printer::JUSTIFY_LEFT);

			$this->printer->feed(1);
			
			// fecha
			$time = '  '.$data->time_label;
			$time .= ' ' . $data->time_date;

			//time
			$date = $data->date_label;
			$date .= ' ' . $data->invoice_date;
			$this->printer->setTextSize(1, 1);
			$this->printer->text(rtrim($this->columnify($date, $time, 55, 45, 0, 0)));
			$this->printer->feed();

			// & sorteo
			$vacio = '';
			$sorteo  = '';
			if (isset($data->sorteo_label) && !empty($data->sorteo_label)) {
				$sorteo = $data->sorteo_label;
				$sorteo .= ' ' . $data->sorteo_date;
			}
			$this->printer->setTextSize(1, 1);
			$this->printer->text(rtrim($this->columnify($sorteo, $vacio, 70, 10, 0, 0)));
			$this->printer->feed(1);

			//Numero de ticket
			$invoice_no = $data->invoice_no_prefix;
			$invoice_no .= ' ' . $data->invoice_no;

			//pin
			$pin = '';			
			if (isset($data->pin_no_prefix) && !empty($data->pin_no_prefix)) {
			$pin = $data->pin_no_prefix;
			$pin .= ' ' . $data->pin_no;
			}	

			$this->printer->text(rtrim($this->columnify($invoice_no, $pin, 50, 50, 0, 0)));
			$this->printer->feed(2);

			$this->printer->setJustification(Printer::JUSTIFY_CENTER);
			//loteria
			$this->printer->setEmphasis(true);
			$this->printer->text($data->loteria);
			$this->printer->setEmphasis(false);
			$this->printer->feed(1);
			
			$this->printer->text($this->drawLine($tipoGuion));

			//lista de jugadas
			if (isset($data->lines) && !empty($data->lines)) {

				$arrayQ = array();
				$arrayPL = array();
				$arrayTP = array();
				$arraySP = array();

				foreach ($data->lines as  $line) {
					$line = (array)$line;

					if ($line['modalidad'] == '1') {
						$arrayQ[] = $line;
					}
					if ($line['modalidad'] == '2') {
						$arrayPL[] = $line;
					}
					if ($line['modalidad'] == '3') {
						$arrayTP[] = $line;
					}
					if ($line['modalidad'] == '4') {
						$arraySP[] = $line;
					}
				}
				if (isset($arrayQ) && !empty($arrayQ)) {
					$this->printer->setJustification(Printer::JUSTIFY_LEFT);
					$this->printer->setEmphasis(true);
					$this->printer->text("QUINIELA" . "\n");
					$this->printer->setEmphasis(false);

					foreach ($arrayQ ?: [] as $line) {

						$this->printer->setEmphasis(true);
						$this->printer->text(rtrim($this->columnify($line['apuesta'], $line['valor'], 70, 30, 0, 0)));
						$this->printer->setEmphasis(false);
						$this->printer->feed();
					}
					$this->printer->text($this->drawLine($tipoGuion));
				}
				if (isset($arrayPL) && !empty($arrayPL)) {
					$this->printer->setJustification(Printer::JUSTIFY_LEFT);
					$this->printer->setEmphasis(true);
					$this->printer->text("PALE" . "\n");
					$this->printer->setEmphasis(false);
					foreach ($arrayPL ?: [] as $line) {
						$this->printer->setEmphasis(true);
						$this->printer->text(rtrim($this->columnify($line['apuesta'], $line['valor'], 70, 30, 0, 0)));
						$this->printer->setEmphasis(false);
						$this->printer->feed();
					}
					$this->printer->text($this->drawLine($tipoGuion));
				}
				if (isset($arrayTP) && !empty($arrayTP)) {
					$this->printer->setJustification(Printer::JUSTIFY_LEFT);
					$this->printer->setEmphasis(true);
					$this->printer->text("TRIPLETA" . "\n");
					$this->printer->setEmphasis(false);
					foreach ($arrayTP ?: [] as $line) {
						$this->printer->setEmphasis(true);
						$this->printer->text(rtrim($this->columnify($line['apuesta'], $line['valor'], 70, 30, 0, 0)));
						$this->printer->setEmphasis(false);
						$this->printer->feed();
					}
					$this->printer->text($this->drawLine($tipoGuion));
				}
				if (isset($arraySP) && !empty($arraySP)) {
					$this->printer->setJustification(Printer::JUSTIFY_LEFT);
					$this->printer->setEmphasis(true);
					$this->printer->text("SUPER PALE" . "\n");
					$this->printer->setEmphasis(false);
					foreach ($arraySP ?: [] as $line) {
						$this->printer->setEmphasis(true);
						$this->printer->text(rtrim($this->columnify($line['apuesta'], $line['valor'], 70, 30, 0, 0)));
						$this->printer->setEmphasis(false);
						$this->printer->feed();
					}
					$this->printer->text($this->drawLine($tipoGuion));
				}
				$this->printer->feed();
			}

			//total
			$total = $data->total_label;
			$total .= ' ' . $data->total;
			$this->printer->setJustification(Printer::JUSTIFY_CENTER);		

			$this->printer->setEmphasis(true);
			$this->printer->text($total);
			$this->printer->setEmphasis(false);			
			$this->printer->feed();

			$this->printer->text($this->drawLine($tipoGuion));

			if (isset($data->promocion_label) && !empty($data->promocion_label)) {
				$this->printer->text($this->drawLine($tipoAsterisco));
				$this->printer->setJustification(Printer::JUSTIFY_CENTER);
				$this->printer->text(strip_tags($data->promocion_label) . "\n");
				$this->printer->text($this->drawLine($tipoAsterisco));
			}

			if (isset($data->estado_label) && !empty($data->estado_label)) {
				$this->printer->text($this->drawLine($tipoAsterisco));
				$this->printer->setJustification(Printer::JUSTIFY_CENTER);
				$this->printer->text(strip_tags($data->estado_label) . "\n");
				$this->printer->text($this->drawLine($tipoAsterisco));
			}

			if (isset($data->footer_text) && !empty($data->footer_text)) {
				$this->printer->setJustification(Printer::JUSTIFY_CENTER);
				$this->printer->feed(1);
				$this->printer->text(strip_tags($data->footer_text) . "\n");
				$this->printer->feed();
			}

			// Barcode
			if (isset($data->barcode) && !empty($data->barcode)) {
				$this->printer->setBarcodeHeight(40);
				$this->printer->setBarcodeWidth(2);
				$this->printer->selectPrintMode();
				$this->printer->setBarcodeTextPosition(Printer::BARCODE_TEXT_BELOW);
				$this->printer->barcode($data->barcode, Printer::BARCODE_CODE39);
				$this->printer->feed();
			}
		}
		
		if($print === 'resultados'){

			//Print logo
			if (isset($data->logo) && !empty($data->logo)) {
				$logo = $this->download_image($data->logo);

				$this->printer->setJustification(Printer::JUSTIFY_CENTER);

				$logo = EscposImage::load($logo, false);
				//$this->printer->graphics($logo);
				$this->printer->bitImage($logo);
			}

			/* Slogan */
			$this->printer->setJustification(Printer::JUSTIFY_CENTER);
			$this->printer->setEmphasis(true);
			$this->printer->setTextSize(1, 1);
			if (isset($data->slogan) && !empty($data->slogan)) {
				$this->printer->text(strip_tags($data->slogan));
				$this->printer->feed();
			}

			/* Nombre empresa */
			if (isset($data->display_name) && !empty($data->display_name)) {
				$this->printer->text($data->display_name);
				$this->printer->feed();
			}


			/* nombre banca */
			if (isset($data->invoice_heading) && !empty($data->invoice_heading)) {
				$this->printer->setEmphasis(true);
				$this->printer->text($data->invoice_heading);
				$this->printer->setEmphasis(false);
				$this->printer->feed(1);
			}

			$this->printer->setJustification(Printer::JUSTIFY_CENTER);

			$this->printer->feed();
			$this->printer->setEmphasis(true);
			$this->printer->text("LISTADO DE NUMEROS GANADORES" . "\n");
			$this->printer->setEmphasis(false);
			$this->printer->feed();
			// fecha
			$start_date = $data->star_label;
			$start_date .= $data->start_date;

			$end_date = $data->end_label;
			$end_date .= $data->end_date;

			$this->printer->setTextSize(1, 1);
			$this->printer->text(rtrim($this->columnify($start_date, $end_date, 50, 50, 0, 0)));
			$this->printer->feed();

			$this->printer->text($this->drawLine($tipoGuion));
			$this->printer->setJustification(Printer::JUSTIFY_LEFT);
			foreach ($data->lines as $line) {
				$line = (array)$line;

				$loteria = $line['nombre'];	

				$numeros = $line['res_premio1'] . ' ' . $line['res_premio2'] . ' ' . $line['res_premio3'];
				
				// $string = rtrim($this->columnify($this->columnify($loteria, 5, 70, 0, 0), $numeros, 70, 75, 0, 0));
				$this->printer->text(rtrim($this->columnify($loteria, $numeros, 80, 30, 0, 0)));
				// $this->printer->text($string);
				$this->printer->feed();
			}
			$this->printer->text($this->drawLine($tipoGuion));

		}
		
			$this->printer->feed();
			$this->printer->cut();

			$this->printer->close();
		}

		// public function open_drawer()
		// {

		// 	$this->printer->pulse();
		// 	$this->printer->close();
		// }
	
	function drawLine($tipo) {

		$new = '';
		for ($i = 1; $i < $this->char_per_line; $i++) {
			$new .= $tipo;
		}
		return $new . "\n";
		
	}
	
	function printLine($str, $size = NULL, $sep = ":", $space = NULL) {
		if (!$size) {
			$size = $this->char_per_line;
		}
		$size = $space ? $space : $size;
		$length = strlen($str);
		list($first, $second) = explode(":", $str, 2);
		$line = $first . ($sep == ":" ? $sep : '');
		for ($i = 1; $i < ($size - $length); $i++) {
			$line .= ' ';
		}
		$line .= ($sep != ":" ? $sep : '') . $second;
		return $line;
	}

	/**
	 * Arrange ASCII text into columns
	 * 
	 * @param string $leftCol
	 *            Text in left column
	 * @param string $rightCol
	 *            Text in right column
	 * @param number $leftWidthPercent
	 *            Width of left column
	 * @param number $rightWidthPercent
	 *            Width of right column
	 * @param number $space
	 *            Gap between columns
	 * @param number $remove_for_space
	 *            Remove the number of characters for spaces
	 * @return string Text in columns
	 */
	function columnify($leftCol, $rightCol, $leftWidthPercent, $rightWidthPercent, $space = 2, $remove_for_space = 0)
	{
		$char_per_line = $this->char_per_line - $remove_for_space;

		$leftWidth = $char_per_line * $leftWidthPercent / 100;
		$rightWidth = $char_per_line * $rightWidthPercent / 100;

		$leftWrapped = wordwrap($leftCol, $leftWidth, "\n", true);
		$rightWrapped = wordwrap($rightCol, $rightWidth, "\n", true);

		$leftLines = explode("\n", $leftWrapped);
		$rightLines = explode("\n", $rightWrapped);
		$allLines = array();
		for ($i = 0; $i < max(count($leftLines), count($rightLines)); $i++) {
			$leftPart = str_pad(isset($leftLines[$i]) ? $leftLines[$i] : "", $leftWidth, " ");
			$rightPart = str_pad(isset($rightLines[$i]) ? $rightLines[$i] : "", $rightWidth, " ");
			$allLines[] = $leftPart . str_repeat(" ", $space) . $rightPart;
		}
		return implode($allLines, "\n") . "\n";
	}

	/**
	 * Check if image is not present than check download and save it.
	 * 
	 * @param string $url
	 */
	function download_image($url){

		$file = basename($url);

		$logo_directory = realpath(dirname(__FILE__) . '/../logos/');
		$logo_image = $logo_directory . '/' . $file;
		
		//Check if the file exists
		//If not, download and store it.
		//Reurn the file path
		$success = true;
		if(!file_exists($logo_image)){
			$image_content = file_get_contents($url);
			$success = file_put_contents($logo_image, $image_content);
		}
		
		if($success){
			return $logo_image;
		} else {
			return false;
		}
	}
}
